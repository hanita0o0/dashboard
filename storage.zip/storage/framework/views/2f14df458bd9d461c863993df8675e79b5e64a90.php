<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>mail</title>
</head>
<body>
<h1>Dear <?php echo e($name); ?> </h1>
<h3><?php echo e($title); ?></h3>
<p><?php echo e($content); ?></p>
</body>
</html>