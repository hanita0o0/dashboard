<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col col-md-4">
            <div class="form-group">
    <?php echo Form::model(['method'=>'post','action'=>['UserController@setPass',$user->id]]); ?>

    <?php echo Form::label('password','رمز جدید '); ?>

    <?php echo Form::text('password',null,['class'=>'form-control']); ?>

            <?php if($errors->has('password')): ?>
                <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($message); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
            <?php endif; ?>
            </div>
            <div class="form-group">
    <?php echo Form::label('password_confirmation','تکرار رمز جدید'); ?>

    <?php echo Form::text('password_confirmation',null,['class'=>'form-control']); ?>

            <?php if($errors->has('password_confirmation')): ?>
                <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('password_confirmation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($message); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
            <?php endif; ?>
            </div>
            <div class="form-group">
                <?php echo Form::submit('ارسال',['class'=>'btn btn-info']); ?>


            </div>
    <?php echo Form::close(); ?>

    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>