<?php $__env->startSection('content'); ?>



<table id="example" class="display" style="width:100%">
    <thead>
    <tr>
        <th>عکس</th>
        <th>کد</th>
        <th>ایجاد کننده</th>
        <th>نام باشگاه</th>
        <th>تاریخ ایجاد</th>
        <th>تاریخ بروزرسانی</th>
        <th style="width: 300px">محتوا</th>
        <th style="width: 200px">عملیات</th>
    </tr>
    </thead>
    <tbody>

    <?php for($i=0 ; $i<count($posts); $i++): ?>

    <tr>

        <td><a ><img height="50" width="50" src="<?php echo e($posts[$i]['media_id'] ? config('constant.post_avatar').$posts[$i]['media_path'] :config('constant.post_avatar').config('constant.noImagePost')); ?>"> </a></td>
        <td><?php echo e($posts[$i]['id']); ?></td>
        <td><?php echo e($posts[$i]['username']); ?></td>
        <td><?php echo e($posts[$i]['eventname']); ?></td>
        <td><?php echo e($posts[$i]['created_at']? $posts[$i]['created_at'] : ""); ?></td>
        <td><?php echo e($posts[$i]['updated_at'] ? $posts[$i]['updated_at'] : ""); ?></td>
        <td ><?php echo e($posts[$i]['body'] ? $posts[$i]['body'] : ""); ?></td>
        <td>
            <button  class="btn btn-sm btn-info "><a href="/posts/clubs/show/<?php echo e($posts[$i]['id']); ?>">مشاهده</a></button>
            <?php echo Form::open(['method'=>'DELETE','action'=>['PostController@delPostClub',$posts[$i]['id']],'style'=>'display:inline-block']); ?>

            <?php echo Form::submit('حذف و ارسال ایمیل',['class'=>'btn-sm btn-danger','onclick'=>"return confirm('آیا مطمئن هستید؟؟؟؟')"]); ?>

            <?php echo Form::close(); ?></td>
    </tr>
    <?php endfor; ?>

    </tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>