<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><h3>افزودن نوع باشگاه</h3></p>
    </div>

    <div class="container row" >
        <div class="col col-md-4" >
            <?php echo Form::open(['method'=>'POST','action'=>['TypeController@store'],'files'=>true]); ?>

            <div class="form-group">
                <?php echo Form::label('name','نام '); ?>

                <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                <?php if($errors->has('name')): ?>
                    <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <?php echo Form::label('description','توضیح'); ?>

                <?php echo Form::textarea('description',null,['class'=>'form-control','rows'=>2]); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('photo_id','عکس:'); ?>

                <?php echo Form::file('photo_id',['class'=>'form-control']); ?>

            </div>
            <div class="form-group" >

                <?php echo Form::submit('افزودن',['class'=>'btn btn-primary']); ?>

            </div>

        </div>

        <?php echo Form::close(); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>