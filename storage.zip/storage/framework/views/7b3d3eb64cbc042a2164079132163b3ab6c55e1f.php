<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><h3>ویرایش باشگاه</h3></p>
    </div>

    <div class="container row" >
        <div class="col col-md-4" >
          <?php echo Form::model($event,['method'=>'PATCH','action'=>['ClubController@update',$event->id],'files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('name','نام باشگاه'); ?>

            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

            <?php if($errors->has('name')): ?>
                <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($message); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <?php echo Form::label('header','شعار باشگاه'); ?>

            <?php echo Form::text('header',null,['class'=>'form-control']); ?>

        </div>
            <div class="form-group">
                <?php echo Form::label('state','استان'); ?>

                <?php echo Form::select('state',[$event->province->id=>$event->province->name]+$state,null,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('city','شهر'); ?>

                <?php echo Form::select('city',[$event->town->id=>$event->town->name]+$city,null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group" >

                <?php echo Form::submit('ویرایش',['class'=>'btn btn-primary']); ?>

            </div>
            </div>

                <div class="col col-md-4" >
                    <div class="form-group">
                        <?php echo Form::label('about','خصوصیات باشگاه'); ?>

                        <?php echo Form::textarea('about',null,['class'=>'form-control','rows'=>3]); ?>

                    </div>
            <div class="form-group">
                <?php echo Form::label('about_team','خصوصیات تیم'); ?>

                <?php echo Form::textarea('about_team',null,['class'=>'form-control','rows'=>3]); ?>

            </div>

                    <div class="form-group">
                        <?php echo Form::label('manager','مدیران'); ?>

                        <select id="manager" class="form-control" multiple="multiple" name="manager[]">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"  <?php $__currentLoopData = $event->tourManagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($manager->id==$user->id): ?>
                                selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('manager')): ?>
                            <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('manager'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($message); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                        <?php endif; ?>
                    </div>

        </div>

            <div class="col col-md-4" style="text-align: right;">
            <img height="250" width="100%" src="<?php echo e(config('constant.club_avatar')); ?>/<?php echo e($event->avatarImage? $event->avatarImage->path :config('constant.noImageClub')); ?>" alt="" class="img-responsive img-rounded">
                <div class="form-group">
                    <?php echo Form::label('avatar','عکس:'); ?>

                    <?php echo Form::file('avatar',['class'=>'form-control']); ?>

                </div>

           </div>

        <?php echo Form::close(); ?>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>