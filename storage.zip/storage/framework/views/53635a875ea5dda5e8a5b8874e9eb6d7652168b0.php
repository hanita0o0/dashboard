<?php $__env->startSection('content'); ?>
    
        
    
    <table id="example" class="display" style="width:100%">
        <thead>
        <tr>
            <th>عکس</th>
            <th>کد</th>
            <th>ایجاد کننده</th>
            <th> نام باشگاه</th>
            <th>تاریخ ایجاد</th>
            <th>تاریخ بروزرسانی</th>
            <th style="width: 300px">محتوا</th>
            <th>عملیات</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a ><img height="50" width="50" src="<?php echo e(config('constant.post_avatar')); ?>/<?php echo e($post->photo? $post->photo->name :config('constant.noImagePost')); ?>"> </a></td>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->user?$post->user->name :""); ?></td>
                <td><?php echo e($post->event?$post->event->name :""); ?></td>
                <td><?php echo e($post->created_at? $post->created_at : ""); ?></td>
                <td><?php echo e($post->updated_at ? $post->updated_at : ""); ?></td>
                <td ><?php echo e($post->body ? $post->body : ""); ?></td>
                <td>
                    <?php echo Form::open(['method'=>'DELETE','action'=>['PostController@destroy',$post->id],'style'=>'display:inline-block']); ?>

                    <?php echo Form::submit('حذف وارسال ایمیل',['class'=>'btn-sm btn-danger','onclick'=>"return confirm('آیا مطمئن هستید؟؟؟؟')"]); ?>

                    <?php echo Form::close(); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>