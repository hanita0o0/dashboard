<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>mail</title>
</head>
<body>
<h1><?php echo e($title); ?></h1>
<h2><?php echo e($content); ?></h2>
</body>
</html>