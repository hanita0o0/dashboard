<?php $__env->startSection('content'); ?>
<?php if(Session::has('update_user')): ?>
<div class="alert alert-danger"><?php echo e(session('update_user')); ?></div>
<?php endif; ?>

<button style="display: inline;" class="btn btn-info"><a href="/trash/posts/all">حذف همه برای همیشه</a></button>
<button class="btn btn-info"><a href="/restore/posts/all">بازیابی همه </a></button><hr>

<table id="example" class="display " >
    <thead>
    <tr >
        <th>عکس</th>
        <th>کد</th>
        <th>ایجاد کننده</th>
        <th> نام باشگاه</th>
        <th>تاریخ ایجاد</th>
        <th>تاریخ بروزرسانی</th>
        <th>عملیات</th>
    </tr>
    </thead>
    <tbody style=" overflow: hidden;text-overflow: ellipsis;">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><a ><img height="50" width="50" src="<?php echo e(config('constant.post_avatar')); ?>/<?php echo e($post->photo? $post->photo->name :config('constant.noImagePost')); ?>"> </a></td>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->user?$post->user->name :""); ?></td>
            <td><?php echo e($post->event?$post->event->name :""); ?></td>
            <td><?php echo e($post->created_at? $post->created_at : ""); ?></td>
            <td><?php echo e($post->updated_at ? $post->updated_at : ""); ?></td>
        <td>
            <button  class="btn btn-danger"><a href="/trash/post/<?php echo e($post->id); ?>">حذف برای همیشه</a></button>
            <button  class="btn btn-danger"><a href="/restore/post/<?php echo e($post->id); ?>">بازیابی</a></button>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>