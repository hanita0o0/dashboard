<?php $__env->startSection('content'); ?>
    <?php if(Session::has('update_type')): ?>
        <div class="alert alert-danger"><?php echo e(session('update_type')); ?></div>
    <?php endif; ?>
    <table id="example" class="display" >
        <thead>
        <tr>
            <th>عکس</th>
            <th>کد</th>
            <th>نام</th>
            <th>تاریخ ایجاد</th>
            <th>تاریخ بروزرسانی</th>
            <th>عملیات</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a ><img height="50" width="50" src="<?php echo e(config('constant.type_avatar')); ?>/<?php echo e($type->photo? $type->photo->path :config('constant.noImageType')); ?>"  > </a></td>
                <td><?php echo e($type->id); ?></td>
                <td><?php echo e($type->name); ?></td>
                <td><?php echo e($type->created_at); ?></td>
                <td><?php echo e($type->updated_at); ?></td>
                
                <td><button class="btn btn-sm btn-success "><a href="<?php echo e(Route('types.edit',$type->id)); ?>">ویرایش</a></button>
                    <button class="btn btn-sm btn-info "><a href="types/<?php echo e($type->id); ?>">مشاهده</a></button>
                    <?php echo Form::open(['method'=>'DELETE','action'=>['RoleController@destroy',$type->id],'style'=>"display: inline"]); ?>

                    <?php echo Form::submit('حذف',['class'=>'btn-sm btn-danger','onclick'=>"return confirm('آیا مطمئن هستید؟؟؟؟')"]); ?>

                    <?php echo Form::close(); ?></td>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>