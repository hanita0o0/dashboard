<?php $__env->startSection('content'); ?>
<?php if(Session::has('update_role')): ?>
<div class="alert alert-danger"><?php echo e(session('update_role')); ?></div>
<?php endif; ?>
<button class="btn btn-info"><a href="roles/create">افزودن نقش</a></button><hr>

<table id="example" class="display" style="width:100%">
    <thead>
    <tr>
        <th>کد</th>
        <th>نام</th>
        <th>توضیح</th>
        <th>تاریخ ایجاد</th>
        <th>تاریخ بروزرسانی</th>
        <th>عملیات</th>
    </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr >
        <td><?php echo e($role->id); ?></td>
        <td><?php echo e($role->name); ?></td>
        <td><?php echo e($role->description? $role->description : ""); ?></td>
        <td><?php echo e($role->created_at?$role->created_at : ""); ?></td>
        <td><?php echo e($role->updated_at?$role->updated_at : ""); ?></td>
        <td ><button class="btn btn-sm btn-success " ><a  href="roles/<?php echo e($role->id); ?>/edit">ویرایش</a></button>
            <?php echo Form::open(['method'=>'DELETE','action'=>['RoleController@destroy',$role->id],'style'=>"display: inline"]); ?>

            <?php echo Form::submit('حذف',['class'=>'btn-sm btn-danger','onclick'=>"return confirm('آیا مطمئن هستید؟؟؟؟')"]); ?>

            <?php echo Form::close(); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>