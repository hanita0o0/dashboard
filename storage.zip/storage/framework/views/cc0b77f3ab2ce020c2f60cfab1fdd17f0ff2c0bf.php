<!-- footer-->
<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>تمامی حقوق برای ویراستار محفوظ می باشد.</p>
        </div>
    </div>
</div>