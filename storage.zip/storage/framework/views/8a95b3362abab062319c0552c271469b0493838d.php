<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><h3>نمایش پست باشگاه</h3></p>
    </div>
    <form action="#">
        <div class="container row" >

            <div class="col col-md-4" >

                <div class="form-group">
                    <label for="id">کد:</label>
                    <input type="text" name="id"  id="id" value="<?php echo e($post->id); ?>" class="form-control" readonly/>
                </div>
                <div class="form-group">
                    <label for="user_id">نام ایجاد کننده </label>
                    <input  type="text" id="user_id" name="user_id" value="<?php echo e($post->user?$post->user->name :""); ?>" class='form-control' readonly>
                </div>
                <div class="form-group">
                    <label for="user_id">نام باشگاه ایجاد کننده </label>
                    <input  type="text" id="user_id" name="user_id" value="<?php echo e($post->event?$post->event->name :""); ?>" class='form-control' readonly>
                </div>
                <div class=form-group>
                    <label for="created_at">تاریخ ایجاد</label>
                    <input type="text" id="created_at" name="created_at" value="<?php echo e($post->created_at?$post->created_at :""); ?>" class='form-control' readonly>
                </div>

                <div class=form-group>
                    <label for="updated_at">تاریخ بروزرسانی</label>
                    <input type="text" id="updated_at" name="updated_at" value="<?php echo e($post->updated_at?$post->updated_at : ""); ?>" class='form-control' readonly>
                </div>

                </div>
            <div class="col col-md-4">
                   <div  class="form-group">
                    <label for="bio">محتوا</label>
                    <textarea id="body" name="body" class="form-control" readonly><?php echo e($post->body?$post->body : ""); ?> </textarea>
                   </div>
                </div>

                <div class="col col-md-4" style="text-align: right;">
                <img height="200" width="100%" style="float: left;margin-bottom: 20px" src="<?php echo e($post->media_id ? config('constant.post_avatar').$media_path :config('constant.post_avatar').config('constant.noImagePost')); ?>" alt="" class="img-responsive img-rounded"  >
                </div>

               </div>


    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>