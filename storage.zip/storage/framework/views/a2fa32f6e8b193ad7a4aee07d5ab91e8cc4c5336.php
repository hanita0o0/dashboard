<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><h3>نمایش باشگاه</h3></p>
    </div>
    <form action="#">
    <div class="container row" >

        <div class="col col-md-4" >

            <div class="form-group">
              <label for="id">کد:</label>
              <input type="text" name="id"  id="id" value="<?php echo e($event->id); ?>" class="form-control" readonly/>
            </div>
            <div class="form-group">
                <label for="name">نام باشگاه</label>
              <input  type="text" id="name" name="name" value="<?php echo e($event->name); ?>" class='form-control' readonly>
            </div>

            <div class="form-group">
                <label for="header">شعار باشگاه</label>
                <input type="text" id="header" name="header" value="<?php echo e($event->header); ?>" class='form-control' readonly>
            </div>
            <div class="form-group">
                <label for="state">استان</label>
                <input  type="text" id="state" name="name" value="<?php echo e($event->province?$event->province->name :""); ?>" class='form-control' readonly>
            </div>
            <div class="form-group">
                <label for="city">شهر</label>
                <input  type="text" id="city" name="city" value="<?php echo e($event->town ? $event->town->name : ""); ?>" class='form-control' readonly>
            </div>
            <div class="form-group">
                <label for="created_at">تاریخ ایجاد</label>
                <input type="text" id="created_at" name="created_at" value="<?php echo e($event->created_at); ?>" class='form-control' readonly>
            </div>

            <div class=form-group>
                <label for="updated_at">تاریخ بروزرسانی</label>
                <input type="text" id="updated_at" name="updated_at" value="<?php echo e($event->updated_at); ?>" class='form-control' readonly>
            </div>
            <div class="form-group">
                <label for="about">خصوصیات باشگاه</label>
                <textarea id="about" name="about" class="form-control" readonly><?php echo e($event->about); ?> </textarea>
            </div>
            <div class="form-group">
                <label for="about_team">خصوصیات تیم</label>
                <textarea id="about_team" name="about"  class="form-control" readonly><?php echo e($event->about_team); ?></textarea>
            </div>

        </div>

        <div class="col col-md-4" >
            <div class=form-group>
                <label for="userName"> مدیر باشگاه</label>
                <input type="text" id="userName" name="userName" value="<?php echo e($event->tourManagers->first() ? $event->tourManagers->first()->name: ""); ?>" class='form-control' readonly>
            </div>
            <div class=form-group>
                <label for="userId"> کد مدیر باشگاه</label>
                <input type="text" id="userId" name="userId" value="<?php echo e($event->tourManagers->first() ? $event->tourManagers->first()->id: ""); ?>" class='form-control' readonly>
            </div>
            <div class=form-group>
                <label for="usersName">مدیران باشگاه</label>
                <textarea rows="2" id="usersName" name="usersName"  class='form-control' readonly><?php $__currentLoopData = $event->tourManagers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($manager->name); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
            </div>



        </div>

     <div class="col col-md-4">
         <a ><img height="200" width="100%" style="margin-bottom:20px" src="<?php echo e(config('constant.club_avatar')); ?>/<?php echo e($event->avatarImage? $event->avatarImage->path :config('constant.noImageClub')); ?>"  > </a>
         <div >
             <a href="<?php echo e($event->id); ?>/edit" style="color: #bd0d13;"><b>جهت ویرایش باشگاه کلیک نمایید</b></a><hr>
         </div>
         <div >
             <a href="subscribes/<?php echo e($event->id); ?>" style="color: #bd0d13"><b> لیست مشترکین باشگاه </b></a>
         </div><br/>
         <div >
             <a href="posts/<?php echo e($event->id); ?>" style="color: #bd0d13"><b> لیست پست های باشگاه </b></a>
         </div><br/>
         <div >
             <a href="tickets/<?php echo e($event->id); ?>" style="color: #bd0d13"><b> لیست تیکت های باشگاه </b></a>
         </div>
     </div>

    </div>
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>