<?php $__env->startSection('content'); ?>

    <table id="example" class="display" style="width:100%">
        <b style="color:#0D47A1;font-size: large;margin-right:40%;">لیست پست های باشگاه</b><hr>
        <thead>
        <tr>
            <th>عکس</th>
            <th>کد</th>
            <th>تاریخ ایجاد</th>
            <th>تاریخ بروزرسانی</th>
            <th style="width: 300px">محتوا</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a ><img height="50" width="50" src="<?php echo e(config('constant.post_avatar')); ?>/<?php echo e($post->photo? $post->photo->name :config('constant.noImagePost')); ?>"> </a></td>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->created_at? $post->created_at : ""); ?></td>
                <td><?php echo e($post->updated_at ? $post->updated_at : ""); ?></td>
                <td ><?php echo e($post->body ? $post->body : ""); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>