<?php $__env->startSection('content'); ?>




<button style="display: inline;" class="btn btn-info"><a href="<?php echo e(Route('postsUsersDel')); ?>">حذف همه برای همیشه</a></button>
<button class="btn btn-info"><a href="<?php echo e(route('PostsUsersRestore')); ?>">بازیابی همه </a></button><hr>

<table id="example" class="display " >
    <thead>
    <tr >
        <th>عکس</th>
        <th>کد</th>
        <th>ایجاد کننده</th>
        
        <th>تاریخ ایجاد</th>
        <th>تاریخ بروزرسانی</th>
        <th>محتوا</th>
        <th>عملیات</th>
    </tr>
    </thead>
    <tbody style=" overflow: hidden;text-overflow: ellipsis;">

    <?php for($i=0 ; $i<count($posts); $i++): ?>

        <tr>
            <td><a ><img height="50" width="50" src="<?php echo e($posts[$i]['media_id'] ? config('constant.post_avatar').$posts[$i]['media_path'] :config('constant.post_avatar').config('constant.noImagePost')); ?>"> </a></td>
            <td><?php echo e($posts[$i]['id']); ?></td>
            <td><?php echo e($posts[$i]['username']); ?></td>
            <td><?php echo e($posts[$i]['created_at']? $posts[$i]['created_at'] : ""); ?></td>
            <td><?php echo e($posts[$i]['updated_at'] ? $posts[$i]['updated_at'] : ""); ?></td>
            <td ><?php echo e($posts[$i]['body'] ? $posts[$i]['body'] : ""); ?></td>
            <td>
            <button  class="btn btn-danger" onclick="return confirm('آیا مطمئن هستید؟؟؟؟')"><a href="<?php echo e(route('postUserDel',$posts[$i]['id'])); ?>">حذف برای همیشه </a></button>
            <button  class="btn btn-danger"><a href="<?php echo e(Route('PostUserRestore',$posts[$i]['id'])); ?>">بازیابی</a></button>
    </tr>
    <?php endfor; ?>
    </tbody>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>