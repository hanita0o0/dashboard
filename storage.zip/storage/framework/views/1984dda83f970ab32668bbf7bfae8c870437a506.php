<?php $__env->startSection('content'); ?>

    <b style="color:#0D47A1;font-size: large;margin-right:40%;">لیست تیکت های باشگاه</b>

<table id="example" class="display"  >
    <thead >
    <tr >
        <th>عکس</th>
        <th>کد</th>
        <th> عنوان تور</th>
        <th>تاریخ شروع</th>
        <th>تاریخ پایان</th>
        <th>تاریخ ایجاد</th>
        <th>تاریخ بروزرسانی</th>
        <th>آدرس</th>
        <th>وضعیت</th>
    </tr>
    </thead>
    <tbody >

    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr >
        <td><a ><img height="50" width="50" src="<?php echo e(config('constant.ticket_avatar')); ?>/<?php echo e($ticket->avatar? $ticket->avatar->path :config('constant.noImageTicket')); ?>"  > </a></td>
        <td><?php echo e($ticket->id); ?></td>
        <td><?php echo e($ticket->name?$ticket->name: ""); ?></td>
        <td><?php echo e($ticket->date?$ticket->date :""); ?></td>
        <td><?php echo e($ticket->end_date?$ticket->end_date :""); ?></td>
        <td><?php echo e($ticket->created_at? $ticket->created_at : ""); ?></td>
        <td><?php echo e($ticket->updated_at? $ticket->updated_at : ""); ?></td>
        <td><?php echo e($ticket->address? $ticket->address : ""); ?></td>
        <td><?php if($ticket->is_active==1): ?> فعال<?php else: ?> غیرفعال <?php endif; ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>