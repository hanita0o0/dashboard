<?php $__env->startSection('content'); ?>
    
        
        
    <table id="example" class="display" style="width:100%">
        <thead>
        <tr>
            <th>عکس</th>
            <th>کد</th>
            <th>نام</th>
            <th>استان</th>
            <th>شهر</th>
            <th>مدیر</th>
            <th>تاریخ ایجاد</th>
            <th>تاریخ بروزرسانی</th>
            <th>عملیات</th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><a ><img height="50" width="50" src="<?php echo e(config('constant.club_avatar')); ?>/<?php echo e($event->avatarImage? $event->avatarImage->path :config('constant.noImageClub')); ?>"  > </a></td>
                <td><?php echo e($event->id); ?></td>
                <td><?php echo e($event->name); ?></td>
                <td><?php echo e($event->province ? $event->province->name : "not assign"); ?></td>
                <td><?php echo e($event->town ? $event->town->name : "not assign"); ?></td>
                <td><?php echo e($event->tourManagers->first() ? $event->tourManagers->first()->name: null); ?></td>
                <td><?php echo e($event->created_at); ?></td>
                <td><?php echo e($event->updated_at); ?></td>
                
                <td><button class="btn btn-sm btn-success "><a href="<?php echo e(Route('clubs.edit',$event->id)); ?>">ویرایش</a></button>
                    <button class="btn btn-sm btn-info "><a href="clubs/<?php echo e($event->id); ?>">مشاهده</a></button>
                    
                    
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>