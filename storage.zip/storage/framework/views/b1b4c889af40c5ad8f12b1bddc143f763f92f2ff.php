<?php $__env->startSection('content'); ?>
    <?php if(Session::has('update_user')): ?>
        <div class="alert alert-danger"><?php echo e(session('update_user')); ?></div>
    <?php endif; ?>
        <?php if(Session::has('set_password')): ?>
            <div class="alert alert-danger"><?php echo e(session('set_password')); ?></div>
    <?php endif; ?>
    <table id="example" class="display"  >
        <thead>
        <tr >
            <th>عکس</th>
            <th>کد</th>
            <th>نام کاربری</th>
            <th>ایمیل</th>
            <th>استان</th>
            <th>شهر</th>
            <th>تلفن</th>
            <th>نقش</th>
            <th style="width: 200px">عملیات</th>
        </tr>
        </thead>
        <tbody >

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr >
            <td><a ><img height="50" width="50" src="<?php echo e(config('constant.user_avatar')); ?>/<?php echo e($user->avatar? $user->avatar->path :config('constant.noImageUser')); ?>"  > </a></td>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->state ? $user->state->name : "not assign"); ?></td>
            <td><?php echo e($user->city ? $user->city->name : "not assign"); ?></td>
            <td ><?php echo e($user->phone); ?>

                <td ><?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($role->name); ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
             <td ><button class="btn btn-sm btn-success "><a href="users/<?php echo e($user->id); ?>/edit">ویرایش</a></button>
                    <button  class="btn btn-sm btn-info "><a href="users/<?php echo e($user->id); ?>">مشاهده</a></button>
                   <?php echo Form::open(['method'=>'DELETE','action'=>['UserController@destroy',$user->id],'style'=>'display:inline-block']); ?>

                   <?php echo Form::submit('حذف',['class'=>'btn-sm btn-danger','onclick'=>"return confirm('آیا مطمئن هستید؟؟؟؟')"]); ?>

                   <?php echo Form::close(); ?>

                 <button  class="btn btn-sm btn-danger "><a href="users/pass/<?php echo e($user->id); ?>">تغیررمز</a></button>
             </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>