<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><h3>ویرایش کاربر</h3></p>
    </div>

    <div class="container row" >
        <div class="col col-md-4" >
            <?php echo Form::model($user,['method'=>'PATCH','action'=>['UserController@update',$user->id],'files'=>true]); ?>

            <div class="form-group">
                <?php echo Form::label('name_header','نام'); ?>

                <?php echo Form::text('name_header',null,['class'=>'form-control']); ?>

                <?php if($errors->has('name_header')): ?>
                    <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('name_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('name','نام کاربری'); ?>

                <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                <?php echo Form::hidden('id',$user->id,['class'=>'form-control']); ?>

                <?php if($errors->has('name')): ?>
                    <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <?php echo Form::label('email','ایمیل'); ?>

                <?php echo Form::text('email',null,['class'=>'form-control']); ?>

                <?php if($errors->has('email')): ?>
                    <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <?php echo Form::label('role[]','نقش'); ?>

                <select name="role[]" multiple="multiple" class="form-control">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($rol->id == $role->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group" >

                <?php echo Form::submit('ویرایش',['class'=>'btn btn-primary']); ?>

            </div>


        </div>

        <div class="col col-md-4" >
            <div class="form-group">
                <?php echo Form::label('state_id','استان'); ?>


                
                <?php echo Form::select('state_id',[$user->state->id=>$user->state->name]+$state,null,['class'=>'form-control','onchange'=>'state(this.value);']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('city_id','شهر'); ?>


                
                
                
                
                
                <?php echo Form::select('city_id',[$user->city->id=>$user->city->name]+$city,null,['class'=>'form-control']); ?>

                
            </div>
            <div class="form-group">
                <?php echo Form::label('phone','تلفن'); ?>

                <?php echo Form::text('phone',null,['class'=>'form-control']); ?>

                <?php if($errors->has('phone')): ?>
                    <span class="help-block" style="color:red"> <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($message); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <?php echo Form::label('bio','بیوگرافی'); ?>

                <?php echo Form::textarea('bio',null,['class'=>'form-control', 'rows' => 4]); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('gender','جنس'); ?>

                <?php echo Form::select('gender',['1'=>'مرد','2'=>'زن'],null,['class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('address','آدرس'); ?>

                <?php echo Form::textarea('address',null,['class'=>'form-control','rows'=>4]); ?>

            </div>
        </div>

        <div class="col col-md-4" >
            <img style='margin-bottom:10px' width="100%" height="250" src="<?php echo e(config('constant.user_avatar')); ?>/<?php echo e($user->avatar? $user->avatar->path :config('constant.noImageUser')); ?>" alt="" class="img-responsive img-rounded">
            <div class="form-group">
                <?php echo Form::label('avatar_id','عکس:'); ?>

                <?php echo Form::file('avatar_id',['class'=>'form-control']); ?>

            </div>
        </div>
        </div>

        <?php echo Form::close(); ?>

        <script>
            function state(str) {

                // var xhttp = new XMLHttpRequest();
                // xhttp.onreadystatechange = function() {
                //     if (this.readyState == 4 && this.status == 200) {
                //      console.log("hello");
                //     }
                // };
                // xhttp.open("GET", '/salam', true);
                //
                // xhttp.send();

                // return x;
            }


        </script>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>